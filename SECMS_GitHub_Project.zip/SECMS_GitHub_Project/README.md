# Student Enrollment & Course Management System (SECMS)

## Project Overview
SECMS is a Salesforce-based academic management application designed to organize student records, course offerings, enrollments, instructor assignments, approval processes, payments, and reporting.

## Team
- Team Lead: Vijayalakshmi M
- Member: Neernisha V

## Technology
- Salesforce
- Data Modeling
- Salesforce Flow / Automation
- Validation Rules
- Reports and Dashboards
- Lightning App / UI

## Project Phases
1. Requirement Analysis & Planning
2. Salesforce Objects & Data Model
3. Relationships, Data Security & Access
4. Automation, Flow & Validation
5. UI/UX & Lightning App
6. Reports & Dashboards
7. Testing & Results
8. Deployment, Documentation, GitHub & Demo

## Important
Screenshots/evidence should be added to each phase folder after the corresponding Salesforce work is completed.
